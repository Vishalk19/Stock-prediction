"A package to build a machine learning model for trading and stock price prediction"

import aialpha.data_processor as data_processor
import aialpha.models as models
